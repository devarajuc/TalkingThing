package com.noise.android.talkingthing;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class BottomNav extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.menu.activity_bottom_nav);
    }
}
